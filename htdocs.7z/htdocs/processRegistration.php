<?php

		
	$username = $_POST['ID'];
	$password = $_POST['Password'];
	$email = $_POST['email'];
	$addy =$_POST['addy'];
	
	
	$cost = 10;

	// Create a random salt
	$salt = strtr(base64_encode(mcrypt_create_iv(16, MCRYPT_DEV_URANDOM)), '+', '.');

	// Prefix information about the hash so PHP knows how to verify it later.
	// "$2a$" Means we're using the Blowfish algorithm. The following two digits are the cost parameter.
	$salt = sprintf("$2a$%02d$", $cost) . $salt;

	// Value:
	// $2a$10$eImiTXuWVxfM37uY4JANjQ==

	// Hash the password with the salt
	$hash = crypt($password, $salt);
	
	//$file = fopen("password.txt","w");
	//fseek($file, -1, SEEK_END);
	file_put_contents("password.txt", $username.'\t', FILE_APPEND);
	file_put_contents("password.txt", $hash.'\t', FILE_APPEND);
	file_put_contents("password.txt", $email.'\t', FILE_APPEND);
	file_put_contents("password.txt", $addy.'\t', FILE_APPEND);
	fclose($file);
	header('Location:./index.html');

?> 