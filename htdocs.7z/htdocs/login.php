<?php
	header('Content-type: text/html; charset=utf-8');
	//include 'initPass.php';
	$file = fopen("password.txt","r");
	$username = $_POST['ID'];
	$fileString = fgetss($file);
	$password = $_POST['Password'];
	$fileStringAry = explode('\t', $fileString);
	$length = count($fileStringAry);
	for($1 =0; $i< $length-3; i++)
	{
		if($i++ %5 === 0 || $i++ === 1)
		{
			if($username == $fileStringAry[i])	
			{
				if(crypt($password, next($fileStringAry)) === $hashPass)
				{
					echo "<label>Verified!</label>";
					echo next($fileStringAry);
				}
				else
					echo "<label>Failed<label>";		
					echo next($fileStringAry);
			
			}
		}
		
	}

	fclose($file);
?> 